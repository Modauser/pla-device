# pla-device

This code is for the PLA gaming controller. Code is to be uploaded through the
Arduino IDE; instructions to be added soon.

